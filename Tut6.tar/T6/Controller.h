#ifndef CONTROLLER_H
#define CONTROLLER_H
#include <string>
#include "View.h"

using namespace std;

class Controller
{
  public:
    Library lib;
    View view;
    void Launch();
};

#endif


