#include <iostream>
using namespace std;
#include <string>

#include "List.h"

List::List() : head(0) { }


List::~List()
{
  Node* currNode = head;
  Node* nextNode;

  while (currNode != NULL) {
    nextNode = currNode->next;
    delete currNode->data;
    delete currNode;
    currNode = nextNode;
  }
 
}

void List::add(Book* book)
{
  Node* tmpNode;
  Node* currNode;
  Node* prevNode;

  tmpNode = new Node;
  tmpNode->data = book;
  tmpNode->next = 0;
  tmpNode->prev = NULL;

  currNode = head;
  prevNode = NULL;

  while (currNode != NULL) {
    if (book->lessThan(currNode->data))
      break;
    prevNode = currNode;
    currNode = currNode->next;
  }
 
  if (prevNode == NULL) {
    head = tmpNode;
    tmpNode->prev = NULL;
  }
  else {
    prevNode->next = tmpNode;
    tmpNode->prev = prevNode;
  }
  tmpNode->next  = currNode;
  if(currNode != NULL){
	currNode->prev = tmpNode;
  }
}

void List::print()
{
 
  Node* currNode = head;

  while (currNode != NULL) {
    currNode->data->print();
    currNode = currNode->next;
    if(currNode->next ==NULL){
	    while(currNode != NULL){
     		currNode->data->print();
     		currNode = currNode->prev;
	    }
    }
  }
  
  //currNode = currNode->prev;
/* 
  while(currNode != head){
     currNode->data->print();
     currNode = currNode->prev;
   }
  */
}


