#ifndef VIEW_H
#define VIEW_H
#include <string>

#include "Library.h"
#include "Book.h"
#include "FictionBook.h"
#include "NonFictionBook.h"

using namespace std;

class View
{
  public:
    int displayMenu();
    void print(Library);
    void readBook(int &, string &, string &, int &);
    bool readBookType();
    string title, author;
    int    id, year;
    int    menuSelection;
    Book*   book1;
    FictionBook* book2;
    NonFictionBook* book3;


};

#endif


