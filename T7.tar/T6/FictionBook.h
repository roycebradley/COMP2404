#ifndef FICTIONBOOK_H
#define FICTIONBOOK_H

#include <string>
using namespace std;

#include "Book.h"

class FictionBook : public Book
{
  public:
    FictionBook(int=0, string="Unknown", string="Unknown", int=0);
};

#endif

