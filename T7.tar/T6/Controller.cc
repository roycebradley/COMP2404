#include <iostream>
#include <iomanip>
using namespace std;

#include "View.h"
#include "Library.h"
#include "Controller.h"



void Controller::Launch()
{

//Book* book1;
FictionBook* ficBook;
NonFictionBook* nonFicBook;
int id, year;
string title, author;

	
  int menuSelection;	
  while (1) {
    menuSelection = view.displayMenu();

  if (menuSelection == 0)
        break;
      else if (menuSelection == 1) {
	      view.readBook(id, title, author, year);

	      if(view.readBookType()){
		     // view.readBook(id, title, author, year);
		      ficBook = new FictionBook(id,title,author,year);
	      	      lounge.addBook(ficBook);
	      }
	      else{ 
		      //view.readBook(id, title, author, year);
		      nonFicBook = new NonFictionBook(id,title,author,year);
	              scs.addBook(nonFicBook);
               }
		      
	     
	     // book1 = new Book(id, title, author, year);
	     // lib.addBook(book1);	
      } 
  }
  cout << "Fiction Library" << endl;
  cout << endl;
  cout << endl;
  view.print(lounge);
  cout << endl;
  cout << endl;
  cout << "Non-Fiction Library" << endl;
  cout << endl;
  view.print(scs);

}

