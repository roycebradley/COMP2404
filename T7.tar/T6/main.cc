#include <iostream>
using namespace std;
#include <string>

#include "Book.h"
#include "Library.h"
#include "Controller.h"
#include "FictionBook.h"
#include "NonFictionBook.h"

#define MAX_ARR_SIZE  128

int  mainMenu();
void printLibrary(Book arr[MAX_ARR_SIZE], int num);


int main()
{
 /* Book   library[MAX_ARR_SIZE];
  Library lib;
  int    numBookz = 0;
  string title, author;
  int    id, year;
  int    menuSelection;
  Book*   book1;
  */
  Controller control;

  control.Launch();
  

  return 0;
}

int mainMenu()
{
  int numOptions = 1;
  int selection  = -1;

  cout << endl;
  cout << "(1) Add book" << endl;
  cout << "(0) Exit" << endl;

  while (selection < 0 || selection > numOptions) {
    cout << "Enter your selection: ";
    cin  >> selection;
  }

  return selection;
}


