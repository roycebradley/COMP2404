#include <iostream>
#include <iomanip>
using namespace std;

#include "FictionBook.h"

FictionBook::FictionBook(int i, string t, string a, int y)
	 : Book(i, t, a, y)
{
/*	
  id     = i;
  title  = t;
  author = a;
  year   = y;
*/
}


