#ifndef CONTROLLER_H
#define CONTROLLER_H
#include <string>
#include "View.h"
#include "FictionBook.h"
#include "NonFictionBook.h"

using namespace std;

class Controller
{
  public:
    Library lib;
    Library scs;
    Library lounge;
    View view;
    void Launch();
};

#endif


