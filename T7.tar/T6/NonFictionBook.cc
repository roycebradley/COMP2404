#include <iostream>
#include <iomanip>
using namespace std;

#include "NonFictionBook.h"

NonFictionBook::NonFictionBook(int i, string t, string a, int y)
         : Book(i, t, a, y)
{
/*      
  id     = i;
  title  = t;
  author = a;
  year   = y;
*/
}


