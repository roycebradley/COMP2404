#include <iostream>
#include <iomanip>
using namespace std;

#include "View.h"
#include "Library.h"
#include "Controller.h"

Library lib;
View view;

void Controller::Launch()
{

Book* book1;
int id, year;
string title, author;

	
  int menuSelection;	
  while (1) {
    menuSelection = view.displayMenu();

  if (menuSelection == 0)
        break;
      else if (menuSelection == 1) {
	      view.readBook(id, title, author, year);
	      book1 = new Book(id, title, author, year);
	      lib.addBook(book1);	
      }
  }

  view.print(lib);

}

