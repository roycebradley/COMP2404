#include <iostream>
using namespace std;
#include <string>

#include "defs.h"
#include "Student.h"
#include "Storage.h"
#include "Course.h"

class Storage;

int  mainMenu();
void printStorage(Student stuArr[MAX_NUM_STU], int);


int main()
{

  Storage store;
  Student* student1;
  Course* course1;
  int     numStu = 0;
  int     numCourses;
  int     stuId, courseCode, grade, term;
  int     menuSelection;
  string    instructor;

  while (1) {
    menuSelection = mainMenu();

    if (menuSelection == 0) 
      break;

    else if (menuSelection == 1) {

      cout << "student id:   ";
      cin  >> stuId;
      student1 = new Student(stuId);

      while (1) {
        cout << "course code <0 to end>:  ";
        cin  >> courseCode;
        if (courseCode == 0)
          break;
        cout << "grade:                   ";
        cin  >> grade;
	cout << "Term:                    ";
	cin >> term;
	cout << "Instructor:              ";
	cin >> instructor;

        course1 = new Course(courseCode, grade, term, instructor);
        student1->addCourse(course1);
      }
     
    }
    store.addStu(student1);
  }

  store.print();

  return 0;
}

int mainMenu()
{
  int numOptions = 1;
  int selection  = -1;

  cout << endl;
  cout << "(1) Add student" << endl;
  cout << "(0) Exit" << endl;

  while (selection < 0 || selection > numOptions) {
    cout << "Enter your selection: ";
    cin  >> selection;
  }

  return selection;
}

