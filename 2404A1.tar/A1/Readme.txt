COMP2404 A1

Author: Royce Bradley - 100988820

The purpose of this software is to provide the user with a tool that stores students and their course records. The user is required to input the Student and Course information and the program will print out the data in a formatted output. 

Files:
main.cc, def.h, Student.cc, Student.h, Course.cc, Course.h, Storage.cc, Storage.h, in.txt, Readme.txt, Makefile

Instructions

Compile the program using the provided Makefile.

The user is now required to provide the program with input. You can do this in 2 ways:
	Run the program and enter the information manually

	or

	Pipline a text document into the program using the format ./sas < in.txt

If information is manually entered the user can end the program using 0 which will result in the student/course data to be printed on screen. This will happen autmatically using pipeling. 


