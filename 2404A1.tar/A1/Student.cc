#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Student.h"

Student::Student(int i)
{
  id = i;
  numCourses = 0;

}

void Student::print()
{
  cout<< endl << "Id: " << id << endl;
	
  for (int i=0; i < numCourses; i++)
  	courses[i]->print();
}

void Student::addCourse(Course* c)
{
	courses[numCourses] = c;
	numCourses++;
}
Student::~Student()
{
  for(int i = 0; i < MAX_NUM_COURSES; i++){
	  delete courses[i];
  }
}

