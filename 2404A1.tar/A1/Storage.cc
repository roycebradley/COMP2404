#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Storage.h"
#include "Student.h"

Storage::Storage()
{
	numStudents = 0;
}

void Storage::addStu(Student* s)
{
	stu[numStudents] = s;
	numStudents++;

}

void Storage::print()
{

  for (int i=0; i < numStudents; i++){
  	stu[i]->print();
  }
}


Storage::~Storage()
{
  for(int i = 0; i < numStudents; i++){
          delete stu[i];
  }
}

