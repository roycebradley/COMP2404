#ifndef STUDENT_H
#define STUDENT_H

#include "defs.h"
#include "Course.h"

class Student
{
  public:
    Student(int=0); //default constructor
    ~Student(); //destructor
    void print(); //print student objects
    void addCourse(Course* ); //add a course pointer to array

  private:
    int    id; //student id
    Course* courses[MAX_NUM_COURSES]; //array of course pointers
    int    numCourses; //number of courses in the array
};

#endif
