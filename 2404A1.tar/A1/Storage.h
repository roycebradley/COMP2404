#ifndef STORAGE_H
#define STORAGE_H

#include "Student.h"

class Storage
{

	public:
		Student* stu[MAX_NUM_STU]; //an arrayof Student pointers
		int numStudents; //number of students in the array
		Storage(); //constructor
		~Storage(); //destructor
		void addStu(Student*); //adds a student pointer to the array
		void print(); //print the stored items



};

#endif

