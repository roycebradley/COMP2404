#include <iostream>
#include <iomanip>
#include <string>
#include <array>
using namespace std;

#include "Array.h"


Array::Array()
{
	//Book element[MAX_ARR_SIZE] = {};
	size = 0;
}

Array::Array(int nBooks)
{
        //Book element[MAX_ARR_SIZE]= {};
       	size = nBooks;
}

void Array::add(Book* b)
{
        //add in asending order
	
	
	element[size] = b;
	size++;
	//Book* temp;
	int count;
	for(int i = 0; i <= size; i++){
		count = i;
		if(element[i]->lessThan(b) == false){
			for(int j = size; j >= i; j--){
				element[j + 1] = element[j];
			}
		break;
		}
	}
	element[count] = b;
        

/*
       	for(int i = 0; i < 100; i++){
		if(!(element[i]->lessThan(b))){
			Book* temp = b;
			for(int j = i; j < 100; j++){
				temp = element[j + 1];
				element[j+1] = element[j];
				element[j] = temp;
			}
			element[i] = b;
			break;
		}	

	}

	
	for(int i = 0; i < size; i++){
		for(int j = i + 1; j < size; j++){
			if((element[i]->year < element[j]->year)){
				temp = element[i];
				element[i] = element[j];
				element[j] = temp;
			}
		}
	}
	*/
}


void Array::print()
{
        cout << endl << endl << "LIBRARY: " << endl;
        for(int i = 0; i < size; i++)
        {
              element[i]->print();
              cout << endl;
        }
}

Array::~Array()
{
 cout<<"-- Array dtor"<<endl;
 for(int i = 0; i < size; i++){
	 delete element[i];
 }
}
