#ifndef ARRAY_H
#define ARRAY_H


#include <string>
using namespace std;

#define MAX_ARR_SIZE  128
#include "Book.h"

class Array
{
  public:
    Array();
    Array(int n);
    ~Array();
    void add(Book* b);
    void print();
 // private:
    Book* element[MAX_ARR_SIZE];
    int size;
};

#endif
