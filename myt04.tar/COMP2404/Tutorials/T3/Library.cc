#include <iostream>
#include <iomanip>
#include <string>
#include <array>
using namespace std;

#include "Library.h"
#include "Array.h"

Library::Library()
{
	Array arr;
}

Library::Library(int nBooks)
{
        Array arr(nBooks);
}

void Library::addBook(Book& b)
{
	arr.add(b);
	//library[numBooks] = b;
	//mBooks++;
}

void Library::print()
{
	//cout << endl << endl << "LIBRARY: " << endl;
	//for(int i = 0; i < numBooks; i++)
	//{
	//	library[i].print();
	//	cout << endl;
	//}
	arr.print();
}
