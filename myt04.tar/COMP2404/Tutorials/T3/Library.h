#ifndef LIBRARY_H
#define LIBRARY_H

#define MAX_ARR_SIZE  128

//class Array;
class Book;
#include "Book.h"
#include "Array.h"

class Library
{	
	public:
		Library();
		Library(int nBooks);
		void addBook(Book& b);
		void print();
		Array arr;
};

#endif
