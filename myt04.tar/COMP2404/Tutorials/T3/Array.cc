#include <iostream>
#include <iomanip>
#include <string>
#include <array>
using namespace std;

#include "Array.h"


Array::Array()
{
	//Book element[MAX_ARR_SIZE] = {};
	size = 0;
}

Array::Array(int nBooks)
{
        //Book element[MAX_ARR_SIZE]= {};
       	size = nBooks;
}

void Array::add(Book& b)
{
        
       	element[size] = b;
	size++;

}

void Array::print()
{
        cout << endl << endl << "LIBRARY: " << endl;
        for(int i = 0; i < size; i++)
        {
              element[i].print();
              cout << endl;
        }
}

