#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Library.h"
class Book;
#include "Book.h"

Library::Library()
{
	numBooks = 0;
}

Library::Library(int nBooks)
{
        numBooks = nBooks;
}

void Library::addBook(Book& b)
{
	library[numBooks] = b;
	numBooks++;
}

void Library::print()
{
	cout << endl << endl << "LIBRARY: " << endl;
	for(int i = 0; i < numBooks; i++)
	{
		library[i].print();
		cout << endl;
	}
}
