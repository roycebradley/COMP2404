
#define MAX_ARR_SIZE  128

class Book;
#include "Book.h"
class Library
{	
	public:
		Library();
		Library(int nBooks);
		Book library[MAX_ARR_SIZE];
		int numBooks;
		void addBook(Book& b);
		void print();
};		
