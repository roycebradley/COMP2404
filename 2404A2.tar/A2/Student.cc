#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Student.h"

Student::Student(int i)
{
  id = i;
  numCourses = 0;

}

void Student::print()
{
  cout<< endl << "Id: " << id << endl;

  list.print();
}

void Student::addCourse(Course* c)
{
	list.add(c);
	numCourses++;
}

