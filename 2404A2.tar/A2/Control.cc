#include <iostream>
#include <iomanip>
using namespace std;

#include "Control.h"

void Control::Launch()
{
	
  int menuSelection;
  while (1) {
    menuSelection = view.displayMenu();

  if (menuSelection == 0)
        break;

  else if (menuSelection == 1) {
		 
	view.readStuId(stuId);
	student1 = new Student(stuId); 
	
	while(1) {
         	view.readCourse(code, grade, term, instructor);
		if(code == 0)
			break;
		
		if(code != 0){
         		course1 = new Course(code, grade, term, instructor);
	 		student1->addCourse(course1);
		}
	}
      }
   storage.addStu(student1);
  }
  view.print(storage);

}

