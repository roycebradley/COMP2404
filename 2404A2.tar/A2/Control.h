#ifndef CONTROL_H
#define CONTROL_H
#include <string>
#include "View.h"

using namespace std;



// The control class is responsible for validating user input and passing it into the model and view//




class Control
{
  public:
    Storage storage;
    View view;
    void Launch();
    Student* student1;
    Course* course1;
  private: 
    int     stuId, grade, term, code;
    string  instructor;
  
};

#endif

