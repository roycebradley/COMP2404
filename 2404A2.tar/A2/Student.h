#ifndef STUDENT_H
#define STUDENT_H

#include "defs.h"
#include "Course.h"
#include "List.h"

//The student class creates student objects// 

class Student
{
  public:
    Student(int=0); //default constructor
    void print(); //print student objects
    void addCourse(Course* ); //add a course pointer to array

  private:
    int    id; //student id
    List  list;
    int    numCourses; //number of courses in the array
};

#endif
