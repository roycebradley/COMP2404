#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "List.h"

List::List() : head(0) { }

List::~List()
{

  Node* currNode = head;
  Node* nextNode;

  while (currNode != NULL) {
    nextNode = currNode->next;
    delete currNode->data;
    delete currNode;
    currNode = nextNode;

    
  }
}

void List::add(Course* c)
{
	Node* tmpNode;
	Node* currNode;
	Node* prevNode;

	tmpNode = new Node;
	tmpNode->data = c;
	tmpNode->next = 0;

	currNode = head;
	prevNode = 0;

	while(currNode != NULL) {
		
		if(currNode->next == NULL)
                        tail = currNode;
                
		
		if(c->lessThan(currNode->data))
			break;
		prevNode = currNode;
		currNode = currNode->next;
		

		
	}

	if (prevNode == NULL) {
		head = tmpNode;
		
	}
	
	else {
		prevNode->next = tmpNode;

	}


	tmpNode->next = currNode;

}

void List::print()
{
  Node* currNode = head;
  Node* headNode = head;
  Node* tailNode = tail;

  while (currNode != NULL) {
    currNode->data->print();
  
    if(currNode->next == NULL){
	   cout << endl;
	   cout << "Head:";
	   headNode->data->print();
	   cout << "Tail:";
           tailNode->data->print();
    }

    currNode = currNode->next;	   
  }  
}


