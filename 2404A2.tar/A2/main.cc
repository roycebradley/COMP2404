#include <iostream>
using namespace std;
#include <string>

#include "defs.h"
#include "Student.h"
#include "Storage.h"
#include "Course.h"
#include "Control.h"


int main()
{
  Control control;
  control.Launch();

  return 0;
}
