#include <iostream>
#include <iomanip>
using namespace std;

#include "View.h"
#include "Course.h"


int View::displayMenu()
{
  int numOptions = 1;
  int selection  = -1;

  cout << endl;
  cout << "(1) Add Student" << endl;
  cout << "(0) Exit" << endl;

  while (selection < 0 || selection > numOptions) {
    cout << "Enter your selection: ";
    cin  >> selection;
  }

  return selection;
}

void View::readStuId(int &id)
{
	cout << "id:  ";
        cin  >> id;
}

void View::readCourse(int &code, int &grade, int &term, string &instructor)
{
   
          cout << "course code <0 to end>:  ";
          cin  >> code;
	  if(code == 0){
		  return;
	  }
          cout << "grade:                   ";
          cin  >> grade;
          cout << "Term:                    ";
          cin >> term;
          cout << "Instructor:              ";
          cin >> instructor;
    

}

void View::print(Storage &store)
{
        store.print();
}


