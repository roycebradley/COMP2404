#ifndef VIEW_H
#define VIEW_H
#include <string>

#include "Storage.h"

using namespace std;


//The view class is responsible for representing the information from the model and control//


class View
{
  public:
    int displayMenu();
    void print(Storage & ); //taking storage param by reference??
    void readStuId(int &);
    void readCourse(int &, int &, int &, string &);
  private:
    int    menuSelection;
};

#endif
