#ifndef LIST_H
#define LIST_H

#include "Course.h"


//The List class initializes a linked list data structure that is responsible for holding students//

class List
{
  class Node
  {
    friend class List;
    private:
      Course*  data;
      Node*    next;
      Node*    prev;

  };

  public:
    List();
    ~List();
    void add(Course*);
    void print();

  private:
    Node* head;
    Node* tail;
};

#endif

